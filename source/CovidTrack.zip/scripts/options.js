import 'emoji-log';

// eslint-disable-next-line no-console
console.emoji('🦄', 'Hello World from options main file!');
